const numbers = [2,4]
console.log(numbers)
for(let i = 0 ; i>numbers.length; i=i+1){
const majmoe=i+i+1
    console.log(majmoe)
}