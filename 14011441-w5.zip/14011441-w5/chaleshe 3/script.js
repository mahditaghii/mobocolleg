const NameAndAge = (name , age) => {
    console.log(name)
    if(age>4){
        console.log("should eat meet")
    }else{
        console.log("should eat milk")
    }
}
console.log(NameAndAge("khargosh" , 3))