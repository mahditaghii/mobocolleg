const localindia = true
const charge = 34
const storage = 10
if (localindia && charge>50 && storage>=10){
    console.log("you can update")
}else{
    console.log("you can't update")
}