function forote(moz,sib,porteghal){
   
console.log("tedade moz" +" "+ moz)
console.log("tedade porteghal" +" "+ porteghal)
console.log("tedade sib" +" "+ sib)
}
forote(3,4,6); 